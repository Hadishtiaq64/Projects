// server.js - Backend API Server
const express = require('express');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const helmet = require('helmet');
const path = require('path');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Optional: log route registration for debugging
const originalGet = app.get.bind(app);
app.get = (...args) => {
  console.log('📡 Registering GET route:', args[0]);
  return originalGet(...args);
};

// Middleware
app.use(helmet());
app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.static('public'));

// Rate limiting middleware
const limiter = rateLimit({
  windowMs: 60 * 1000,
  max: 10,
  message: {
    success: false,
    error: 'Too many requests from this IP, please try again later.',
    retryAfter: 60,
  },
  standardHeaders: true,
  legacyHeaders: false,
});
app.use('/api/', limiter);

// Usage stats
let usageStats = {
  totalBuilds: 0,
  dailyBuilds: 0,
  lastReset: new Date().toDateString(),
};

function resetDailyStats() {
  const today = new Date().toDateString();
  if (usageStats.lastReset !== today) {
    usageStats.dailyBuilds = 0;
    usageStats.lastReset = today;
  }
}

// Gemini API call
async function callGeminiAPI(prompt) {
  const GEMINI_API_KEY = process.env.GEMINI_API_KEY;
  if (!GEMINI_API_KEY) throw new Error('Gemini API key not configured');

  // --- MODIFICATION START ---
  // Updated the URL to use the stable v1 API and a current model (gemini-1.5-flash).
  // This resolves the 404 error from using the old v1beta endpoint.
  const response = await fetch(
    `https://generativelanguage.googleapis.com/v1/models/gemini-1.5-flash:generateContent?key=${GEMINI_API_KEY}`,
    {
  // --- MODIFICATION END ---
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{ parts: [{ text: prompt }] }],
        generationConfig: {
          temperature: 0.7,
          topK: 40,
          topP: 0.95,
          maxOutputTokens: 2048,
        },
        safetySettings: [
          { category: "HARM_CATEGORY_HARASSMENT", threshold: "BLOCK_MEDIUM_AND_ABOVE" },
          { category: "HARM_CATEGORY_HATE_SPEECH", threshold: "BLOCK_MEDIUM_AND_ABOVE" }
        ],
      }),
    }
  );

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    throw new Error(`Gemini API error: ${response.status} - ${errorData.error?.message || 'Unknown error'}`);
  }

  const data = await response.json();
  return data?.candidates?.[0]?.content?.parts?.[0]?.text || 'No valid response from Gemini API';
}

// Prompt builder
function buildPrompt(budget, useCase, customPrompt) {
  let prompt = `You are an expert PC builder and hardware specialist. Please recommend a complete PC build based on the following requirements:\n\n`;
  if (budget) prompt += `💰 Budget: ${budget}\n`;
  if (useCase) prompt += `🎯 Primary Use: ${useCase}\n`;
  if (customPrompt) prompt += `📝 Additional Requirements: ${customPrompt}\n`;

  prompt += `
Please provide a comprehensive PC build recommendation with:

1. **COMPLETE PARTS LIST**
2. **PRICING BREAKDOWN**
3. **PERFORMANCE EXPECTATIONS**
4. **TECHNICAL DETAILS**
5. **ASSEMBLY GUIDANCE**
6. **ALTERNATIVES & UPGRADES**

Use emojis and clear formatting. Focus on value, performance, and reliability.`;

  return prompt;
}

// Health check
app.get('/api/health', (req, res) => {
  res.json({
    success: true,
    status: 'healthy',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
  });
});

// Usage stats
app.get('/api/stats', (req, res) => {
  resetDailyStats();
  res.json({
    success: true,
    stats: {
      totalBuilds: usageStats.totalBuilds,
      dailyBuilds: usageStats.dailyBuilds,
      serverUptime: Math.floor(process.uptime()),
      lastReset: usageStats.lastReset,
    },
  });
});

// Main generation endpoint
app.post('/api/generate-pc-build', async (req, res) => {
  const startTime = Date.now();

  try {
    const { budget, useCase, customPrompt } = req.body;
    if (!budget && !useCase && !customPrompt) {
      return res.status(400).json({ success: false, error: 'Missing required fields.' });
    }

    resetDailyStats();
    const prompt = buildPrompt(budget, useCase, customPrompt);
    const recommendation = await callGeminiAPI(prompt);

    usageStats.totalBuilds++;
    usageStats.dailyBuilds++;

    res.json({
      success: true,
      recommendation,
      metadata: {
        responseTime: Date.now() - startTime,
        timestamp: new Date().toISOString(),
        buildId: `build_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        stats: {
          totalBuilds: usageStats.totalBuilds,
          dailyBuilds: usageStats.dailyBuilds,
        },
      },
    });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({
      success: false,
      error: error.message || 'Internal Server Error',
      metadata: {
        responseTime: Date.now() - startTime,
        timestamp: new Date().toISOString(),
      },
    });
  }
});

// ✅ SAFE FALLBACK ROUTE using app.use (not app.get('*')) for Express 5+
app.use((req, res, next) => {
  const url = req.originalUrl;

  // Block malformed paths like /:https://...
  if (/\/:[^\/]+/.test(url) && !/^\/:[a-zA-Z0-9_]+$/.test(url)) {
    console.warn('❌ Blocked malformed route request:', url);
    return res.status(400).send('Malformed route: unsupported pattern.');
  }

  // Serve index.html for all frontend SPA paths
  if (req.method === 'GET' && !req.path.startsWith('/api')) {
    return res.sendFile(path.join(__dirname, 'public', 'index.html'), (err) => {
      if (err) {
        console.error('Error serving index.html:', err);
        return res.status(500).send('Error loading application.');
      }
    });
  }

  next(); // pass to 404 or error middleware if not handled
});

// Global error handler
app.use((error, req, res, next) => {
  console.error('Unhandled server error:', error);
  res.status(500).json({
    success: false,
    error: 'Internal server error',
    timestamp: new Date().toISOString(),
  });
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down...');
  process.exit(0);
});
process.on('SIGINT', () => {
  console.log('SIGINT received, shutting down...');
  process.exit(0);
});

// Start server
app.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
  if (!process.env.GEMINI_API_KEY) {
    console.warn('⚠️ Warning: GEMINI_API_KEY not set.');
  }
});

module.exports = app;
process.env.GEMINI_API_KEY = process.env.GEMINI_API_KEY || 'AIzaSyAu8eBl9uueav3w-N3OYuD-UIn2pL-FZkA';
console.log('--- RUNNING NEW CODE ---');